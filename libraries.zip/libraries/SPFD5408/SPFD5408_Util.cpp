///////////////////////////////////
// Library: SPFD5408 Library
// File: SPFD5408_Util.cpp
// Author: Joao Lopes
// Comments: Some utilities for TFTLCD
// Versions:
//  0.8 First beta - July 15
///////////////////////////////////

#include "Arduino.h"
#include "SPFD5408_Util.h"
